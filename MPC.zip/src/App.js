import logo from './logo.svg';
import './App.css';
import Wall from "../src/components/Wall"
import Google_Auth from './components/Google_Auth';
import Signup from './components/Signup';

function App() {
  return (
    <div className="App">
     <Wall/>
     <br/>
      <br />
      <br />
      <br />
     <Google_Auth/>
     <Signup/>
    </div>
  );
}

export default App;
