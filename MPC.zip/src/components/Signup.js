import React, { useState } from 'react';
import axios from 'axios';

function Signup() {
    const [post, setPost] = useState({
        firstName: '',
        lastName: '',
        email: '',
        picture: 
    });

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post('/api/posts/create', post);
            console.log(response.data); // log the response data
        } catch (error) {
            console.error(error);
        }
    };

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setPost((prevPost) => ({
            ...prevPost,
            [name]: value,
        }));
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="title" value={post.title} onChange={handleInputChange} />
            <textarea name="content" value={post.content} onChange={handleInputChange}></textarea>
            <input type="text" name="author" value={post.author} onChange={handleInputChange} />
            <button type="submit">Submit</button>
        </form>
    );
}
export default Signup;